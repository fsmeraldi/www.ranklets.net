/* Testranklets.c (C) Fabrizio Smeraldi 2003      */
/* Free for non-commercial use - all other rights */
/* reserved                                       */
/* Demonstrates the ranklet computation routine   */
/* Try running with and without NORMALIZE defined */
/* and with and without HALFRANKS defined in      */
/* ranklets.h */

#include<stdio.h>
#include"ranklets.h"

#define XSIZE 8
#define YSIZE 4

int main(void)
{
    /* Holds a test image */
    IMAGETYPE image[YSIZE][XSIZE];
    int x, y, i;
    float rklet;

    /* Fill the test image with progressive numbers */
    i=1;
    for (y=0; y<YSIZE;++y)
	for (x=0; x<XSIZE; ++x)
	    image[y][x]=i++;

    /* Display the test image */
    printf("\nA simple test image with no ties:\n\n");
    for (y=0; y<YSIZE;++y)
	{
	    for (x=0; x<XSIZE; ++x)
		printf("%2d ", image[y][x]);
	    printf("\n");
	}

    /* IMPORTANT: Use rksetnewimage to set the working image each time
       it is modified, even if the pointer stays the same */
    rksetnewimage(XSIZE, YSIZE, &image[0][0]);

    /* Compute sample ranklets and print out the result */
    printf("\nSyntax: ranklets(x0, y0, xhalfw, yhalfw, direction)\n\n");

    rklet=ranklet(1,1,1,1,VERT);
    printf("ranklet(1,1,1,1,VERT)  = %f\n",rklet);
    rklet=ranklet(1,1,1,1,HORIZ);
    printf("ranklet(1,1,1,1,HORIZ) = %f\n",rklet);
    rklet=ranklet(1,1,1,1,DIAG);
    printf("ranklet(1,1,1,1,DIAG)  = %f\n\n",rklet);

    rklet=ranklet(4,2,4,2,VERT);
    printf("ranklet(4,2,4,2,VERT)  = %f\n",rklet);
    rklet=ranklet(4,2,4,2,HORIZ);
    printf("ranklet(4,2,4,2,HORIZ) = %f\n",rklet);
    rklet=ranklet(4,2,4,2,DIAG);
    printf("ranklet(4,2,4,2,DIAG)  = %f\n\n",rklet);

    /************* Now with a constant test image *******************/
    for (y=0; y<YSIZE;++y)
	for (x=0; x<XSIZE; ++x)
	    image[y][x]=+1;

    /* Display the test image */
    printf("\nTest image with many tied pixels.\n");
    printf("Output on this image does not make sense\n");
    printf("unless HALFRANKS is defined:\n\n");
    for (y=0; y<YSIZE;++y)
	{
	    for (x=0; x<XSIZE; ++x)
		printf("%2d ", image[y][x]);
	    printf("\n");
	}
    printf("\n");

    /* Note that we have to call this again because the image
       has changed */
    rksetnewimage(XSIZE, YSIZE, &image[0][0]);

    rklet=ranklet(4,2,4,2,VERT);
    printf("ranklet(4,2,4,2,VERT)  = %f\n",rklet);
    rklet=ranklet(4,2,4,2,HORIZ);
    printf("ranklet(4,2,4,2,HORIZ) = %f\n",rklet);
    rklet=ranklet(4,2,4,2,DIAG);
    printf("ranklet(4,2,4,2,DIAG)  = %f\n\n",rklet);

    /*********** Now with a test image with two values *********/
    for (y=0; y<YSIZE;++y)
	for (x=0; x<XSIZE; ++x)
	    if ( ((x<XSIZE/2) && (y<YSIZE/2)) ||
		 ((x>=XSIZE/2) && (y>=YSIZE/2)) )
		image[y][x]=+2;
	    else
		image[y][x]=+1;

    /* Display the test image */
    printf("\nTest image with many tied pixels.\n");
    printf("Output on this image does not make sense\n");
    printf("unless HALFRANKS is defined:\n\n");
    for (y=0; y<YSIZE;++y)
	{
	    for (x=0; x<XSIZE; ++x)
		printf("%2d ", image[y][x]);
	    printf("\n");
	}
    printf("\n");

    /* Note that we have to call this again because the image
       has changed */
    rksetnewimage(XSIZE, YSIZE, &image[0][0]);

    rklet=ranklet(4,2,4,2,VERT);
    printf("ranklet(4,2,4,2,VERT)  = %f\n",rklet);
    rklet=ranklet(4,2,4,2,HORIZ);
    printf("ranklet(4,2,4,2,HORIZ) = %f\n",rklet);
    rklet=ranklet(4,2,4,2,DIAG);
    printf("ranklet(4,2,4,2,DIAG)  = %f\n\n",rklet);


    /**************** Finally with three values *****************/
    for (y=YSIZE/2; y<YSIZE;++y)
	for (x=XSIZE/2; x<XSIZE; ++x)
	    image[y][x]=+3;

    /* Display the test image */
    printf("\nTest image with many tied pixels.\n");
    printf("Output on this image does not make sense\n");
    printf("unless HALFRANKS is defined:\n\n");
    for (y=0; y<YSIZE;++y)
	{
	    for (x=0; x<XSIZE; ++x)
		printf("%2d ", image[y][x]);
	    printf("\n");
	}
    printf("\n");

    /* Note that we have to call this again because the image
       has changed */
    rksetnewimage(XSIZE, YSIZE, &image[0][0]);

    rklet=ranklet(4,2,4,2,VERT);
    printf("ranklet(4,2,4,2,VERT)  = %f\n",rklet);
    rklet=ranklet(4,2,4,2,HORIZ);
    printf("ranklet(4,2,4,2,HORIZ) = %f\n",rklet);
    rklet=ranklet(4,2,4,2,DIAG);
    printf("ranklet(4,2,4,2,DIAG)  = %f\n\n",rklet);

    return 0;
}


/* Tested image sizes up to 32*32 with int image type,
   pixel values increasing from 1 to 1024. No overflow
   detected. The correct results (not normalised) are

ranklet(16,16,16,16,VERT, &image[0][0]) = 126976.000000
ranklet(16,16,16,16,HORIZ,&image[0][0]) = 0.000000
ranklet(16,16,16,16,DIAG, &image[0][0]) = 131072.000000

*/
