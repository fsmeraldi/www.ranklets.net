/* Ranklets.c -  (C) Fabrizio Smeraldi 2002-2006  */
/* Free for non-commercial use - all other rights */
/* reserved                                       */


#include"ranklets.h"
#include<stdio.h>
#include<stdlib.h>

/* Sorting buffers are statically allocated here
for increased speed */
static int pixbuff[MAXWINAREA];
static int xbuff[MAXWINAREA];
static int ybuff[MAXWINAREA];
static int key[MAXWINAREA];
#ifdef HALFRANKS
static float hrank[MAXWINAREA];
#endif

/* X and Y size of the images we shall operate on, and a pointer
to the image itself */
static int xsize=-10000; /* guaranteed to wreak havoc  if   */
static int ysize=-10000; /* you forget to call rksetnewimage */
static IMAGETYPE *image=NULL;
static int newimageflag=0; /* Flags an image change */

/********** Extern function prototypes ************/

/* Set the working image and its size */
void rksetnewimage(int xsz,int ysz,IMAGETYPE *img);
/* Compute a ranklet at coordinates x0, y0 with half window size
   along the two axes specified by xhalfw and yhalfw, tuned to
   the specified direction */
float ranklet(int x0, int y0, int xhalfw, int yhalfw,
	      enum directions direction);

/*********** Static function prototypes ***********/

/* Sort a subwindow; return the number of pixels */
static int sortwindow(int x0, int y0, int xhalfw, int yhalfw);

/* Order function for sorting */
static int ascending (const void *a, const void *b);

#ifdef HALFRANKS
/* Compute the ranks of tied pixels */
static void computehalfranks(int npoints);
#endif

/**************************************************/


/* Compute a ranklet at coordinates x0, y0 with half window size
   along the two axes specified by xhalfw and yhalfw, tuned to
   the specified direction */
float ranklet(int x0, int y0, int xhalfw, int yhalfw,
	       enum directions direction)
{
  /* These four variables are used to decide whether we should
     compute the ranking for a new window or not */
  static int oldx0=-1, oldy0=-1, oldxhalfw=-1, oldyhalfw=-1;
  static int npoints=-1;

  int i;
  int y, x;
  float rklet;
  
  if ((xhalfw!=oldxhalfw)||(yhalfw!=oldyhalfw)||
      (x0!=oldx0)||(y0!=oldy0)||(newimageflag!=0))
      {
	  /* The window and/or the image have changed;
	     recompute the order */
          npoints=sortwindow(x0,y0,xhalfw,yhalfw);
	  /* If HALFRANKS is defined, account properly for
	     tied pixels */
#ifdef HALFRANKS
	  computehalfranks(npoints);
#endif
	  /* Update the window */
	  oldx0=x0; oldy0=y0;
	  oldxhalfw=xhalfw; oldyhalfw=yhalfw;
	  /* Reset the "new image" flag */
	  newimageflag=0;
      }


  /* Compute Mann-Whitney statistics Wxy= Ws -1/2 n (n+1)
     where n is the number of treatment ranks  - see Lehmann,
     Nonparametrics, page 9, Eq. (1.13) */
  rklet = -npoints*((npoints/2)+1)/4;

  /* Subtract the average if NORMALIZE is defined */
#ifdef NORMALIZE
  rklet-=npoints*npoints/8;
#endif

  switch(direction) {
    case VERT: /* left half Treatment, right half Control */
	for (i=0; i<npoints; ++i)
	    {
		x=xbuff[key[i]];
		if (x<0)
#ifdef HALFRANKS
		    rklet+=hrank[i];
#else
		    rklet+=i;
#endif
	    }
	break;

    case HORIZ:  /* upper half Treatment, lower half Control */
	for (i=0; i<npoints; ++i)
	    {
		y=ybuff[key[i]];
		if (y<0) 
#ifdef HALFRANKS
		    rklet+=hrank[i];
#else
		    rklet+=i;
#endif
	    }
	break;

    case DIAG: /* Upper left and lwr right Treatment, rest Controls */
	 for (i=0; i<npoints; ++i)
	     {
		 y=ybuff[key[i]];
		 x=xbuff[key[i]];
		 if ( ((x<0) && (y<0)) ||
		      ((x>=0) && (y>=0)) )
#ifdef HALFRANKS
		     rklet+=hrank[i];
#else
		     rklet+=i;
#endif
	     }
	 break;
    default:
	printf("RANKLET: Invalid direction %d\n", direction);
	exit(1);
  }

  /* Compensate for the fact that ranks start from 1 while
     variable i or the halfranks above start from 0 */
  rklet+=npoints/2;

  /* If NORMALIZE is defined, divide by half the maximum value
     so that the result ranges from -1 to +1 */
#ifdef NORMALIZE
  rklet/=npoints*npoints/8;   
#endif

  return rklet;
}


/* Sort a subwindow; return the number of pixels - note: there
is no check for image boundaries */
int sortwindow(int x0, int y0, int xhalfw, int yhalfw)
{
  int i,y,x;
  int npoints;
  int *pixptr, *xptr, *yptr;

  /* Number of points in the window */
  npoints=4*xhalfw*yhalfw;
  
  /* Check for buffer overflow */
  if (npoints>MAXWINAREA)
      {
	  printf("RANKLETS: Subwindow size exceeded: increase MAXWINAREA\n");
	  exit(1);
      }
  
  /* copy pixel intensity values and coordinates into buffer */
  pixptr=pixbuff; xptr=xbuff; yptr=ybuff;
  for (y=y0-yhalfw; y<y0+yhalfw;++y)
      for (x=x0-xhalfw; x<x0+xhalfw;++x)
	  {
	      *(pixptr++)=(int) *(image+y*xsize+x);
	      *(xptr++)=x-x0;
	      *(yptr++)=y-y0;
	  }

  /* init the key array */
  for (i=0; i<npoints; ++i) key[i]=i;

  /* order the key array */
  qsort (key, npoints, sizeof(int), ascending);

  return npoints;
}


/* Sort key array based on ascending intensity of the
   indexed pixels */
int ascending (const void *a, const void *b)
{
  return pixbuff[* (int *)a]- pixbuff[* (int *)b];
}


/* Set the working image and its size */
void rksetnewimage (int xsz, int ysz, IMAGETYPE *img)
{
    /* These are global static variables */
    xsize=xsz;
    ysize=ysz;
    image=img;
    /* Signal that the image is new and the ranking should
       be recomputed */
    newimageflag=1;
}


#ifdef HALFRANKS
/* Compute the halfranks of tied pixels - halfranks are
computed starting from 0 instead than starting from 1.
This is compensated for in function ranklets. */

static void computehalfranks(int npoints)
{
  int i, j, k;

  hrank[npoints-1]=-1;
  for (i=0; i<npoints-1; ++i)
      {
	j=i+1;
	while ((pixbuff[key[j]]==pixbuff[key[i]]) && (++j<npoints));
	if (--j>i) 
	  {
	    for (k=i; k<=j; ++k)
	      hrank[k]=(float) (i+j)/2.0;
	    i=j; /* Skip forward */
	  }
	else
	  hrank[i]=i;
      }	
  if (hrank[npoints-1]==-1) hrank[npoints-1]=npoints-1;
}
#endif
