/* ranklets.h -  (C) Fabrizio Smeraldi 2002-2009  */
/* http://www.ranklets.net                        */
/* Free for non-commercial use - all other rights */
/* reserved                                       */

/* Compute ranklets based on counting sort. The histogram
   of each window area is computed at each time explicitly
   and cached. */

/* This version has all function names prefixed by a h */
/* to allow for use in conjunction with countingsort */
/* ranklets for comparison. Duplicated definitions may */
/* be commented out */



#ifndef __RANKLETS__
#define __RANKLETS__

/***************** User customisable defines ******************/


/* When NORMALIZE is defined, ranklets are normalized between
   -1 and +1. Comment this define out to obtain the integer
   value of Wxy */
#define NORMALIZE 

/* When HALFRANKS is defined, half ranks are computed for tied
pixels (see Lehmann, Nonparametrics, page 22). Comment this out
to treat tied pixels as all other pixels */
#define HALFRANKS 

/* Number of grey levels in the intensity scale - max 256 */
#define GREYLEVELS 256

/* Histogram type - int or long int */
typedef int HISTOTYPE; 

/*   Feature type - float or double  */
typedef float FEATURETYPE; 


/* Image type - will be cast to int */
typedef unsigned char IMAGETYPE; 

/*************** Make no changes below this point *************/

/* The three possible ranklet types. This diagram shows the
disposition of the T and C sets, assuming that the x axis
points right and the y axis points down:

      VERT        HORIZ       DIAG

    T T C C      T T T T     T T C C
    T T C C      T T T T     T T C C
    T T C C      C C C C     C C T T
    T T C C      C C C C     C C T T
*/
enum orientation {VERT=0, HORIZ=1, DIAG=2}; 


/* Set the working image for the ranklets routine. 
   IMPORTANT: Call each time the working image is
   changed to prevent the caching of ranks from the
   old image, even if the address stays the same.
   NOTE: By calling this function a pointer
   to the image is stored, but the image is NOT
   copied. The image cannot be freed or overwritten
   for as long as the ranklets should be computed.
*/ 
extern void rksetnewimage(int xsz, int ysz, const IMAGETYPE *img);

/* Compute a ranklet at coordinates x0, y0 with half window size
   along the two axes specified by xhalfw and yhalfw, tuned to
   the specified direction. If xhalfw=3, yhalfw=2 and direction
   is DIAG the following ranklet is computed:

                       T T T C C C
		       T T T C C C
		       C C C t T T
		       C C C T T T
    
   where the lowercase t marks the pixel with coordinates (x0,y0)
   in the image. No attempt is made to check that the subwindow
   lies entirely within the image, so the programmer should make
   sure that it does before calling this function.
*/
extern float ranklet(int x0, int y0, int xhalfw, int yhalfw,
        	      enum orientation orient);


#endif
