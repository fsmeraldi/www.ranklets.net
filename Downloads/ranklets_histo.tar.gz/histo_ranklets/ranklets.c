/* ranklets.c -  (C) Fabrizio Smeraldi 2002-2009  */
/* http://www.ranklets.net                        */
/* Free for non-commercial use - all other rights */
/* reserved                                       */

/* Compute ranklets based on counting sort. The histogram
   of each window area is computed at each time explicitly
   and cached. */

/* This version has all function names prefixed by a h */
/* to allow for use in conjunction with countingsort */
/* ranklets for comparison. Duplicated definitions may */
/* be commented out */

#include"ranklets.h"

#include<stdlib.h>
#include<string.h>
#include<stdio.h>

/* X and Y size of the images we shall operate on, and a pointer
to the image itself */
static int xsize=-10000; /* guaranteed to wreak havoc  if   */
static int ysize=-10000; /* you forget to call rksetnewimage */
static const IMAGETYPE *image=NULL;
static int newimageflag=0; /* Flags an image change */


/* Exported functions */
FEATURETYPE ranklet (int x0, int y0,  int xhalfw, int yhalfw,
		      enum orientation orient);
void rksetnewimage (int xsz, int ysz, const IMAGETYPE *img);



/* Static functions */
static void gethistogramwbounds (int x0, int y0, int x1, int y1,
		int *imin, int *imax, HISTOTYPE *hist);
static void gethistogram (int x0, int y0, int x1, int y1, 
		   HISTOTYPE *hist);



/* Set the working image and its size */
void rksetnewimage (int xsz, int ysz, const IMAGETYPE *img)
{
    /* These are global static variables */
    xsize=xsz;
    ysize=ysz;
    image=img;
    /* Signal that the image is new and the ranking should
       be recomputed */
    newimageflag=1;
}



/* Compute a ranklet with the required orientation. Use pre-cached histograms
   if the support window has not been changed */
FEATURETYPE ranklet (int x0, int y0,  int xhalfw, int yhalfw,
        	      enum orientation orient)
{
  /* Values from the previous invocation */
  static int oldx0=-1, oldy0=-1;
  static int oldxhalfw=-1, oldyhalfw=-1;

  /* Histogram of the entire subwindow */
  static HISTOTYPE histogram[GREYLEVELS];
  static FEATURETYPE midrank[GREYLEVELS];

  /* Min and max intensity values involved */
  static int imin, imax;
  /* Number of treatment pixels */
  static int ntreat;

  HISTOTYPE tset[GREYLEVELS]; /* T set for the specific ranklet */
  HISTOTYPE temp[GREYLEVELS]; 

  HISTOTYPE r;
  FEATURETYPE wstat;
  int i;


  /* If the image has changed or the support window has changed, we 
     we recompute the four corners */
  if ((x0!=oldx0)||(y0!=oldy0)||(xhalfw!=oldxhalfw)||
      (yhalfw!=oldyhalfw)||newimageflag)
    {
      /* Compute the histograms of the four corners and also get bounds */
      gethistogramwbounds (x0-xhalfw, y0-yhalfw, 
			   x0+xhalfw-1, y0+yhalfw-1, &imin, &imax, histogram);

      /* Compute midranks */
      r=1; /* next unassigned rank available */
      for (i=imin; i<=imax; ++i)
	if (histogram[i])
	  {
	    midrank[i]=r+(float) histogram[i]/2.0-0.5;
	    r+=histogram[i];
	  }
      /* Number of treatment pixels */
      ntreat=2*xhalfw*yhalfw;
      /* Store coordinates of the support window */
      oldx0=x0; oldy0=y0;
      oldxhalfw=xhalfw; oldyhalfw=yhalfw;
      /* Mark image as seen */
      newimageflag=0;
    }
  
  /* Compute T set according to the orientation required by 
     the user */
  switch (orient)
    {
    case VERT: /* Left half of the window */
      gethistogram (x0-xhalfw, y0-yhalfw, x0-1, y0+yhalfw-1, tset);
      break;

    case HORIZ: /* Top half of the window */
      gethistogram (x0-xhalfw, y0-yhalfw, x0+xhalfw-1, y0-1, tset); 
      break;

    case DIAG: /* Top left and lower right squares */
      /* Need an intermediate step */
      gethistogram (x0-xhalfw, y0-yhalfw, x0-1, y0-1, tset);
      gethistogram (x0, y0, x0+xhalfw-1, y0+yhalfw-1, temp);
      for (i=imin; i<=imax; ++i)
	tset[i]=tset[i]+temp[i];
      break;
    default: 
      printf ("Invalid orientation\n");
      exit(1);
    }

  /* Compute the Wilcoxon statistics */
  wstat=0.0;
  for (i=imin; i<=imax; ++i)
    wstat+=tset[i]*midrank[i];
    
#ifndef NORMALIZE
  /* Compute the Mann-Whitney statistics  Wxy= Ws -1/2 n (n+1)
     where n is the number of treatment ranks  - see Lehmann,
     Nonparametrics, page 9, Eq. (1.13) */
  wstat-=ntreat*(ntreat+1)/2;
#else
  /* Compute the Mann-Whitney statistics and take away the 
     average n*n/2 */
  wstat-=ntreat*((FEATURETYPE) ntreat+0.5);
  /* Divide by the maximum value n*n/2 so that the features 
     are in the range between -1 and 1 */
  wstat*=2.0/(FEATURETYPE) (ntreat*ntreat);
#endif
  
  return wstat;
}


/* Compute the histogram of the image between the start and end
   coordinates specified. return min and max intensities */
void gethistogramwbounds (int x0, int y0, int x1, int y1, 
			  int *imin, int *imax, HISTOTYPE *hist)
{
  int x, y;
  const IMAGETYPE *pix;

  *imin=GREYLEVELS; *imax=0;

  /* Zero target histogram */
  memset (hist,0, sizeof(HISTOTYPE)*GREYLEVELS);

  for (y=y0; y<=y1; ++y)
    {
      pix=image+y*xsize+x0;
      for (x=x0; x<=x1; ++x)
	{
	  ++hist[*pix];
	  if (*pix<*imin) *imin=*pix;
	  if (*pix>*imax) *imax=*pix;
	  ++pix;
	}
    }
}



/* Compute the histogram of the image between the start and end
   coordinates specified.don't worry about min and max intensity */
void gethistogram (int x0, int y0, int x1, int y1, 
		   HISTOTYPE *hist)
{
  int x, y;
  const IMAGETYPE *pix;

  /* Zero target histogram */
  memset (hist,0, sizeof(HISTOTYPE)*GREYLEVELS);

  for (y=y0; y<=y1; ++y)
    {
      pix=image+y*xsize+x0;
      for (x=x0; x<=x1; ++x)
	++hist[*(pix++)];
    }
}
