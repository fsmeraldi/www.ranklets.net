/* RANKLETS.C (C) Fabrizio Smeraldi, July 2008               */
/* http://www.ranklets.net                                   */
/* Efficiently compute the ranklet decomposition of an image */
/* using  an on-line counting sort algorithm                 */

/* Free for non-commercial use - all other rights  reserved  */

#include "ranklets.h"
#include <string.h>

void ranklets (FEATURETYPE *decomp, int xhalfw, int yhalfw, int xsize,
		int ysize, const IMAGETYPE *image);


/* See header file for a description of the parameters */
void ranklets (FEATURETYPE *decomp, int xhalfw, int yhalfw, int xsize,
		int ysize, const IMAGETYPE *image)
{ 
  float midrank[256]={0}; /* holds midranks */
  int minval, maxval; /* area of histogram that's occupied */
  int *histogram; /* Will point to the histogram used for sorting */
  /* T sets of the ranklets in the tree directions */
  int *vtset, *htset, *dtset;
  /* Values for leftmost ranklet stored here to avoid rescanning at
     each new line */
  int *ohist;
  int ominval, omaxval;
  int *ovtset, *ohtset, *odtset;
  /* The actual memory for the arrays defined above is allocated here */
  int buffer1[256*4]={0}; /* all other elements init to 0 as if static */
  int buffer2[256*4]={0};
  /* Pointers to the decomposition "sheets" */
  FEATURETYPE *vertptr, *horizptr, *diagptr;
  FEATURETYPE wsvert, wshoriz, wsdiag; /* The Wilcoxon statistics */
  int ntreat; /* Number of points in the T sets */ 
  int x,y; /* running coordinates on the image */ 
  int i,j; /* coordinates in the subwindow */
  int pixval; /* image pixel value */
  int k, r;
  int *swap;

 /* Pointers to the different "sheets" of the decomposition, for 
     convenience */
  vertptr=decomp;
  horizptr=decomp+xsize*ysize;
  diagptr=decomp+2*xsize*ysize;

  /* Zero all of the decomposition efficiently */
  memset(decomp, 0, 3*xsize*ysize*sizeof(FEATURETYPE));
  /* Check that the image is large enough for the ranklet to be 
     computed at least at one position; otherwise return */
  if ((ysize<2*yhalfw)||(xsize<2*xhalfw)) return;
  /* Number of points in the T set */
  ntreat=2*xhalfw*yhalfw;

  /* Pointers to the various histograms. Using these allows
   swapping the buffers efficiently further down */
  histogram=&buffer1[0]; vtset=&buffer1[256];
  htset=&buffer1[256*2]; dtset=&buffer1[256*3];
  ohist=&buffer2[0]; ovtset=&buffer2[256];
  ohtset=&buffer2[256*2]; odtset=&buffer2[256*3];
 
  /* "Pre-load" the histograms for the start leaving out the rightmost
     column and lowermost row. Similarly "trim" the T sets */
  minval=255; maxval=0;
  for (j=-yhalfw; j<yhalfw-1; ++j)
    for (i=-xhalfw; i<xhalfw-1; ++i)
      {
	pixval=image[(yhalfw+j)*xsize+(xhalfw+i)];
	++histogram[pixval];
	minval=pixval<minval?pixval:minval; /* Update min and max values */
	maxval=pixval>maxval?pixval:maxval;
	/* Refer to sketch in header file for a definition of the T sets */
	if (i<-1) ++vtset[pixval];
	if (j<-1) ++htset[pixval];
	if ((i<-1 && j<-1)||(i>=0 && j>=0)) ++dtset[pixval];
      }

  /* Line by line sweep top to bottom */
  for (y=yhalfw; y<=ysize-yhalfw; ++y)
    {
      /* Add the last row of the subwindow except for the rightmost
	 pixel - now just the rightmost column is missing */
      for (i=-xhalfw; i<xhalfw-1; ++i)
	{
	  pixval=image[(y+yhalfw-1)*xsize+(xhalfw+i)];
	  ++histogram[pixval];
	  minval=pixval<minval?pixval:minval; /* Update min and max values */
	  maxval=pixval>maxval?pixval:maxval;
	  if (i<-1) ++vtset[pixval];
	  if (i>=0)  ++dtset[pixval];
	  /* Add the "upper mid row" to the horizontal and diagonal T sets */
	  pixval=image[(y-1)*xsize+(xhalfw+i)];
	  ++htset[pixval];
	  if (i<-1) ++dtset[pixval];
	}

      /* This is our starting point for the row. Only the rightmost column
	 of the window and the "left mid" column are missing. We save this
	 for the start of the next image line */
      memcpy(ohist, histogram, 256*sizeof(int));
      memcpy(ovtset, vtset, 256*sizeof(int));
      memcpy(ohtset, htset, 256*sizeof(int));
      memcpy(odtset, dtset, 256*sizeof(int));
      ominval=minval; omaxval=maxval;

      /* Sweep left to right */
      for (x=xhalfw; x<=xsize-xhalfw; ++x)
	{
	  /* Add the rightmost column of the subwindow to be sorted */
	  for (j=-yhalfw; j<yhalfw; ++j)
	    {
	      pixval=image[(y+j)*xsize+(x+xhalfw-1)];
	      ++histogram[pixval];
	      minval=pixval<minval?pixval:minval; /* Update min,max vals */
	      maxval=pixval>maxval?pixval:maxval;
	      if (j<0) ++htset[pixval];
	      else ++dtset[pixval];
	      /* Add the "left mid column" to the vertical and diagonal
		 T sets */
	      pixval=image[(y+j)*xsize+(x-1)];
	      ++vtset[pixval];	
	      if (j<0) ++dtset[pixval];
	    }
	  
	  /**** All histograms are now ready. Computation of ranklets ****
	   **** starts here                                           ****/ 

	  /* Compute the midranks */
	  r=1; /* next unassigned current rank */
	  /* Histogram positions outside this range are unoccupied */
	  for (k=minval; k<=maxval; ++k)
	    if (histogram[k]) /* midrank undefined otherwise */
	      {
		midrank[k]=r+(float) histogram[k]/2.0-0.5;
		r+=histogram[k];
	      }
	  /* Compute the Wilcoxon statistics */
	  wsvert=wshoriz=wsdiag=0.0;
	  for (k=minval; k<=maxval; ++k)
	    { 
	      wsvert+=vtset[k]*midrank[k];
	      wshoriz+=htset[k]*midrank[k];
	      wsdiag+=dtset[k]*midrank[k];
	    }
	  
#ifndef NORMALIZE
	  /* Compute the Mann-Whitney statistics  Wxy= Ws -1/2 n (n+1)
	     where n is the number of treatment ranks  - see Lehmann,
	     Nonparametrics, page 9, Eq. (1.13) */
	  wsvert-=ntreat*(ntreat+1)/2;
	  wshoriz-=ntreat*(ntreat+1)/2;
	  wsdiag-=ntreat*(ntreat+1)/2;
#else
	  /* Compute the Mann-Whitney statistics and take away the 
	     average n*n/2 */
	  wsvert-=ntreat*((FEATURETYPE) ntreat+0.5);
	  wshoriz-=ntreat*((FEATURETYPE) ntreat+0.5);
	  wsdiag-=ntreat*((FEATURETYPE) ntreat+0.5);
	  /* Divide by the maximum value n*n/2 so that the features 
	     are in the range between -1 and 1 */
	  wsvert*=2.0/(FEATURETYPE) (ntreat*ntreat);
	  wshoriz*=2.0/(FEATURETYPE) (ntreat*ntreat);
	  wsdiag*=2.0/(FEATURETYPE) (ntreat*ntreat);
#endif
	  /* Write the values to the decomposition array */
	  vertptr[y*xsize+x]=wsvert;
	  horizptr[y*xsize+x]=wshoriz;
	  diagptr[y*xsize+x]=wsdiag;
  
	  /**** Computation of ranklets ends here ****/

	  /* To prepare for next point to the right, remove the
	     leftmost column from histogram and T sets */
	  for (j=-yhalfw; j<yhalfw; ++j)
	    {
	      pixval=image[(y+j)*xsize+(x-xhalfw)];
	      --histogram[pixval];
	      --vtset[pixval];
	      if (j<0) 
		{ --htset[pixval];
		  --dtset[pixval]; }
	    }
	  /* Update the min and max values */
	  while (histogram[minval]==0) ++minval;
	  while (histogram[maxval]==0) --maxval;

	  /* Remove the "right mid column" from the diagonal
	     T set */
	  for (j=0; j<yhalfw; ++j)
	    {
	      pixval=image[(y+j)*xsize+x];
	      --dtset[pixval];
	    }	  
	} /* End of x sweep */

      /* To prepare for the next y sweep, copy the histograms for the
	 leftmost x value back into place. This is achieved more efficiently
	 by swapping the pointers */
      swap=histogram; histogram=ohist; ohist=swap;
      swap=vtset; vtset=ovtset; ovtset=swap;
      swap=htset; htset=ohtset; ohtset=swap;
      swap=dtset; dtset=odtset; odtset=swap;
      minval=ominval; maxval=omaxval;

      /* Note that the rightmost column and the "left mid" column are 
	 missing here */

      /* Remove the topmost row from histogram and T sets */
      for (i=-xhalfw; i<xhalfw-1; ++i)
	{
	  pixval=image[(y-yhalfw)*xsize+(xhalfw+i)];
	  --histogram[pixval];
	  --htset[pixval];
	  if (i<-1) 
	    { --vtset[pixval];
	      --dtset[pixval]; }
	}
      /* Update the min and max values */
      while (histogram[minval]==0) ++minval;
      while (histogram[maxval]==0) --maxval;

      /* Remove the "lower mid row" from the  diagonal T set */
      for (i=0; i<xhalfw-1; ++i)
	{
	  pixval=image[y*xsize+(xhalfw+i)];
	  --dtset[pixval];
	}
    } /* End of y sweep */
}


