/* ranklets.h -  (C) Fabrizio Smeraldi 2009  */
/* http://www.ranklets.net                   */
/* Free for non-commercial use - all other rights */
/* reserved                                       */

#ifndef  __RANKLETS__
#define __RANKLETS__

/***************** User customisable defines ******************/

/* When NORMALIZE is defined, ranklets are normalized between
   -1 and +1. Comment this define out to obtain the integer
   value of Wxy */
#define NORMALIZE 

/* Image type */
typedef unsigned char IMAGETYPE;
/* Feature type - float or double */
typedef float FEATURETYPE;

/*************** Make no changes below this point *************/

/* The three possible ranklet types. This diagram shows the
disposition of the T and C sets, assuming that the x axis
points right and the y axis points down:

      VERT        HORIZ       DIAG

    T T C C      T T T T     T T C C
    T T C C      T T T T     T T C C
    T T c C      C C c C     C C t T
    T T C C      C C C C     C C T T
*/
enum orientation {VERT=0, HORIZ=1, DIAG=2}; 


/*  Compute the ranklets with half window size along the two axes
    specified by xhalfw and yhalfw over the entire image. Store
    them in decomp as three layered images:  decomp[orientation][y][x].
    Alignement of the responses on the (x,y) grid is as shown in the
    sketch above: the lowercase letter marks the pixel considered as 
    the centre of the ranklet. This assumes that the x axis points 
    right and the y axis down.

    The return image decomp[orient][y][x] should have the same size
    as the original image for each value of orient; only the ranklets 
    that fit completely inside the image are computed, while those that
    overlap the image border are set to zero. */
extern void ranklets (FEATURETYPE *decomp, int xhalfw, int yhalfw, int xsize,
		      int ysize, const IMAGETYPE *image);

#endif
